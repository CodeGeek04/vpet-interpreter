This file will soon host an overview of the project's structure for contributors.

## Roadmap

● Support running LLMs locally (Code-Llama)  <br>
○ Eric Allen's `--scan` mode security measures, powered by GuardDog and Semgrep  <br>
○ Identical CLI ↔ Python functionality, including resuming chats  <br>
○ **Desktop application** ([sign up for early access](https://openinterpreter.com)) 
