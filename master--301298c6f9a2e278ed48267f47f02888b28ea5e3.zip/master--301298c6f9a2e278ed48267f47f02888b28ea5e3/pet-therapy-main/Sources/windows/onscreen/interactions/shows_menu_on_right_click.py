from yage.models.capability import Capability


class ShowsMenuOnRightClick(Capability):
    def __init__(self):
        pass
