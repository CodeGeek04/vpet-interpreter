class PetSize:
    min_size = 25
    max_size = 350
    default_size = 75
