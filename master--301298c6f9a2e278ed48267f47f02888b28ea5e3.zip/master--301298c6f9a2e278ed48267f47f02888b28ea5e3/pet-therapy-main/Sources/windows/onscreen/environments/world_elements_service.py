from typing import List
from yage.models.entity import Entity
from yage.models.world import World


class WorldElementsService:
    def elements(self, world: World) -> List[Entity]:
        return []
