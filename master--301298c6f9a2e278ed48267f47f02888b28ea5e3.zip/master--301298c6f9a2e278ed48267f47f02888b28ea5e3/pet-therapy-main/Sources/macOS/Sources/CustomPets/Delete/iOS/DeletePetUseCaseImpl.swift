import Foundation
import Schwifty
import SwiftUI
import Swinject
import Yage

class DeletePetUseCaseImpl: DeletePetUseCase {
    func safelyDelete(item: Species) -> Bool {
        false
    }
}
