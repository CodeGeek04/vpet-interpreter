import Schwifty
import SwiftUI

typealias DesktopInteractionsSwitch = EmptyView
typealias LaunchAtLoginSwitch = EmptyView
typealias LaunchSilentlySwitch = EmptyView
typealias ScreensOnOffSettings = EmptyView
