import XCTest
@testable import Mobile_Pets

final class MobilePetsTests: XCTestCase {
    func testExample() throws {
        XCTAssert(true)
    }
}
