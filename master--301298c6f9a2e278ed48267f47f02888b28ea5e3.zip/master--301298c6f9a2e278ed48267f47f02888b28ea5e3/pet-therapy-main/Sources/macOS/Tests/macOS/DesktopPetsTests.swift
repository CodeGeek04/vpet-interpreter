import XCTest

final class DesktopPetsTests: XCTestCase {
    func testExample() throws {
        XCTAssert(true)
    }
}
